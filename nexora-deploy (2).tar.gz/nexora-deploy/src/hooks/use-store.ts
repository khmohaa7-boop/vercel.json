import { useMemo } from 'react';
import { suppliers, completeBundle, type Category } from '@/lib/data';

export function useSuppliers(category?: Category | 'todos') {
  return useMemo(() => {
    if (!category || category === 'todos') return suppliers;
    return suppliers.filter(s => s.category === category);
  }, [category]);
}

export function useSupplier(id: string) {
  return useMemo(() => {
    return suppliers.find(s => s.id === id) || null;
  }, [id]);
}

export function useBundle() {
  return completeBundle;
}
