import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  ArrowRight,
  ShieldCheck,
  Zap,
  Tag,
  Headset,
  CheckCircle2,
  Package,
  Star,
  Headphones,
  Droplets,
  Shirt
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { CountdownTimer } from "@/components/ui/countdown";
import { useSuppliers, useBundle } from "@/hooks/use-store";
import { formatPrice } from "@/lib/utils";

const testimonials = [
  {
    name: "Carlos M.",
    avatar: "https://i.pravatar.cc/150?u=carlos",
    text: "Compré el acceso de AirPods y la calidad es brutal. El margen de ganancia es enorme.",
    role: "Revendedor"
  },
  {
    name: "Laura G.",
    avatar: "https://i.pravatar.cc/150?u=laura",
    text: "Me pillé el pack completo y es la mejor inversión. Proveedores súper fiables y rápidos.",
    role: "Emprendedora"
  },
  {
    name: "David R.",
    avatar: "https://i.pravatar.cc/150?u=david",
    text: "Por 9.99€ tener acceso directo a perfumes de lujo... Ya he hecho 3 pedidos sin problemas.",
    role: "Cliente VIP"
  }
];

export default function Home() {
  const suppliers = useSuppliers();
  const bundle = useBundle();

  const getIconForCategory = (categoryId: string) => {
    switch (categoryId) {
      case 'airpods': return <Headphones className="w-12 h-12 text-primary" />;
      case 'perfumes': return <Droplets className="w-12 h-12 text-primary" />;
      case 'ropa': return <Shirt className="w-12 h-12 text-primary" />;
      default: return <Package className="w-12 h-12 text-primary" />;
    }
  };

  return (
    <div className="flex flex-col w-full overflow-hidden bg-black text-white">
      {/* 1. HERO — productos visibles directamente */}
      <section className="relative min-h-screen flex flex-col justify-center pt-24 pb-16">
        <div className="absolute inset-0 z-0">
          <img
            src={`${import.meta.env.BASE_URL}images/hero-bg.png`}
            alt="Hero Background"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/90 via-black/70 to-black" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          {/* Badge social proof */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex justify-center mb-8"
          >
            <div className="flex items-center gap-2 bg-white/5 border border-white/10 px-4 py-2 rounded-full">
              <div className="flex -space-x-2">
                {[1, 2, 3].map(i => (
                  <img key={i} src={`https://i.pravatar.cc/100?img=${i}`} className="w-6 h-6 rounded-full border border-black" alt="User" />
                ))}
              </div>
              <span className="text-sm text-zinc-300 flex items-center gap-1">
                <Star className="w-4 h-4 text-primary fill-primary" />
                <span className="text-white font-bold">+600</span> clientes satisfechos
              </span>
            </div>
          </motion.div>

          {/* Título corto */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-center text-3xl md:text-4xl font-display font-bold text-white mb-12"
          >
            Elige tu acceso. <span className="text-primary">Compra directo al proveedor.</span>
          </motion.h1>

          {/* Las 3 tarjetas visibles en el hero */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {suppliers.map((supplier, index) => (
              <motion.div
                key={supplier.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                className="group relative bg-zinc-900/80 backdrop-blur-sm rounded-2xl border border-white/10 hover:border-primary/60 transition-all duration-300 overflow-hidden flex flex-col"
              >
                {supplier.badge && (
                  <div className="absolute top-4 right-4 z-10 bg-primary text-black text-[10px] font-black tracking-widest uppercase px-3 py-1 rounded-full">
                    {supplier.badge}
                  </div>
                )}
                {/* Icono */}
                <div className="flex items-center justify-center py-12 bg-black/40 group-hover:bg-primary/5 transition-colors duration-300">
                  <div className="w-24 h-24 rounded-full bg-zinc-900 border border-white/10 group-hover:border-primary/50 flex items-center justify-center group-hover:scale-110 transition-all duration-300 shadow-xl">
                    {getIconForCategory(supplier.id)}
                  </div>
                </div>

                <div className="p-6 flex flex-col flex-grow">
                  <h3 className="text-xl font-display font-bold text-white mb-1">{supplier.name}</h3>
                  <p className="text-zinc-400 text-sm mb-4 line-clamp-2">{supplier.tagline}</p>

                  <ul className="space-y-2 mb-6 flex-grow">
                    {supplier.includes.slice(0, 3).map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-zinc-300 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="flex items-center justify-between pt-4 border-t border-white/10">
                    <div>
                      <span className="text-2xl font-bold text-white">{formatPrice(supplier.price)}</span>
                      {supplier.originalPrice && (
                        <span className="text-sm text-zinc-500 line-through ml-2">{formatPrice(supplier.originalPrice)}</span>
                      )}
                    </div>
                    <Button asChild size="sm" className="shrink-0">
                      <Link href={`/producto/${supplier.id}`}>Comprar</Link>
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Pack completo CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="mt-8 max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 bg-primary/10 border border-primary/30 rounded-2xl px-6 py-5"
          >
            <div className="flex items-center gap-4">
              <Package className="w-8 h-8 text-primary shrink-0" />
              <div>
                <p className="text-white font-bold text-lg">Pack Completo — Los 3 accesos juntos</p>
                <p className="text-zinc-400 text-sm">Ahorra {Math.round((1 - bundle.price / bundle.originalPrice) * 100)}% frente a comprarlos por separado</p>
              </div>
            </div>
            <div className="flex items-center gap-4 shrink-0">
              <div className="text-right">
                <div className="text-2xl font-bold text-white">{formatPrice(bundle.price)}</div>
                <div className="text-sm text-zinc-500 line-through">{formatPrice(bundle.originalPrice)}</div>
              </div>
              <Button asChild size="lg" className="shadow-[0_0_20px_rgba(217,160,32,0.3)]">
                <Link href="/producto/pack-completo">Ver Pack</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 2. SOCIAL PROOF BAR */}
      <section className="border-y border-white/10 bg-zinc-950/80 py-6 backdrop-blur-md sticky top-16 z-40 hidden md:block">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap items-center justify-center gap-8 md:gap-16">
            <div className="flex items-center gap-3 text-zinc-300 font-medium">
              <ShieldCheck className="w-6 h-6 text-primary" /> Proveedor verificado
            </div>
            <div className="flex items-center gap-3 text-zinc-300 font-medium">
              <Zap className="w-6 h-6 text-primary" /> Acceso inmediato
            </div>
            <div className="flex items-center gap-3 text-zinc-300 font-medium">
              <Tag className="w-6 h-6 text-primary" /> Precio único
            </div>
            <div className="flex items-center gap-3 text-zinc-300 font-medium">
              <Headset className="w-6 h-6 text-primary" /> Soporte incluido
            </div>
          </div>
        </div>
      </section>

      {/* 4. PACK COMPLETO */}
      <section className="py-24 relative overflow-hidden bg-zinc-950">
        <div className="absolute inset-0 z-0">
          <img
            src={bundle.imageUrl}
            alt={bundle.name}
            className="w-full h-full object-cover opacity-20 mix-blend-overlay"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/90 to-black/80" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="max-w-5xl mx-auto glass-panel border border-primary/30 rounded-3xl p-8 md:p-16 relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 blur-[100px] rounded-full pointer-events-none" />
            
            <div className="flex flex-col lg:flex-row items-center justify-between gap-12 relative z-10">
              <div className="lg:w-1/2 text-center lg:text-left">
                <div className="inline-flex items-center gap-2 bg-primary text-black text-sm font-bold px-4 py-1.5 rounded-full mb-6 uppercase tracking-wider">
                  <Star className="w-4 h-4 fill-black" />
                  MEJOR VALOR - AHORRA {Math.round((1 - bundle.price / bundle.originalPrice) * 100)}%
                </div>
                
                <h2 className="text-4xl md:text-6xl font-display font-bold text-white mb-6">
                  {bundle.name.split('—')[0]} <br />
                  <span className="text-gradient-gold">COMPLETO</span>
                </h2>
                
                <p className="text-lg text-zinc-300 mb-8 max-w-md mx-auto lg:mx-0">
                  {bundle.description}
                </p>

                <div className="space-y-3 mb-8 text-left max-w-md mx-auto lg:mx-0">
                  {bundle.suppliers.map(s => (
                    <div key={s.id} className="flex items-center gap-3 text-zinc-200 bg-white/5 border border-white/5 p-3 rounded-lg">
                      {getIconForCategory(s.id)}
                      <span className="font-medium">{s.name}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="lg:w-1/2 flex flex-col items-center justify-center p-8 bg-black/60 rounded-2xl border border-white/10 w-full lg:w-auto min-w-[320px]">
                <div className="text-zinc-500 line-through text-2xl font-bold mb-2">{formatPrice(bundle.originalPrice)}</div>
                <div className="text-6xl font-bold text-gradient-gold mb-8">{formatPrice(bundle.price)}</div>
                
                <Button asChild size="lg" className="w-full h-16 text-lg font-bold shadow-[0_0_30px_rgba(217,160,32,0.3)] hover:shadow-[0_0_50px_rgba(217,160,32,0.5)]">
                  <Link href="/producto/pack-completo">CONSEGUIR LOS 3 ACCESOS</Link>
                </Button>
                <p className="text-sm text-zinc-400 mt-4 text-center">Pago único. Acceso de por vida.</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 5. CÓMO FUNCIONA */}
      <section className="py-24 bg-black">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-display font-bold text-white mb-4">
              CÓMO <span className="text-gradient-gold">FUNCIONA</span>
            </h2>
            <p className="text-zinc-400 text-lg">Un proceso simple y directo para empezar tu negocio hoy mismo.</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12 max-w-5xl mx-auto relative">
            <div className="hidden md:block absolute top-12 left-1/6 right-1/6 h-0.5 bg-gradient-to-r from-primary/10 via-primary/50 to-primary/10" />
            
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }} className="relative z-10 flex flex-col items-center">
              <div className="w-24 h-24 rounded-full bg-zinc-950 border-2 border-primary flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(217,160,32,0.2)] text-3xl font-display font-bold text-primary">1</div>
              <h3 className="text-xl font-bold text-white mb-3">Elige tu acceso</h3>
              <p className="text-zinc-400">Selecciona el proveedor individual que buscas o el pack completo para mayor ahorro.</p>
            </motion.div>
            
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.2 }} className="relative z-10 flex flex-col items-center">
              <div className="w-24 h-24 rounded-full bg-zinc-950 border-2 border-primary flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(217,160,32,0.2)] text-3xl font-display font-bold text-primary">2</div>
              <h3 className="text-xl font-bold text-white mb-3">Realiza el pago</h3>
              <p className="text-zinc-400">Completa tu pago seguro de forma rápida. Es un pago único, sin suscripciones mensuales.</p>
            </motion.div>
            
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.3 }} className="relative z-10 flex flex-col items-center">
              <div className="w-24 h-24 rounded-full bg-zinc-950 border-2 border-primary flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(217,160,32,0.2)] text-3xl font-display font-bold text-primary">3</div>
              <h3 className="text-xl font-bold text-white mb-3">Recibe tu enlace</h3>
              <p className="text-zinc-400">Obtén acceso inmediato al proveedor verificado para empezar a comprar a precio de mayorista.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 6. TESTIMONIOS */}
      <section className="py-24 bg-zinc-950 border-y border-white/5">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-display font-bold text-white mb-4">
              CLIENTES <span className="text-gradient-gold">SATISFECHOS</span>
            </h2>
            <p className="text-zinc-400 text-lg">Más de 600 emprendedores ya están multiplicando sus beneficios.</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {testimonials.map((testi, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-black border border-white/10 rounded-2xl p-8 hover:border-primary/30 transition-colors"
              >
                <div className="flex items-center gap-1 mb-6">
                  {[1, 2, 3, 4, 5].map(star => (
                    <Star key={star} className="w-5 h-5 text-primary fill-primary" />
                  ))}
                </div>
                <p className="text-zinc-300 text-lg mb-8 italic">"{testi.text}"</p>
                <div className="flex items-center gap-4">
                  <img src={testi.avatar} alt={testi.name} className="w-12 h-12 rounded-full border border-primary/50" />
                  <div>
                    <div className="font-bold text-white">{testi.name}</div>
                    <div className="text-sm text-primary">{testi.role}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. EMAIL CAPTURE */}
      <section className="py-32 relative bg-black">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(217,160,32,0.1)_0%,transparent_70%)]" />
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto glass-panel border border-white/10 p-10 md:p-16 rounded-3xl text-center"
          >
            <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">
              Únete y obtén un <span className="text-gradient-gold">15% de descuento</span>
            </h2>
            <p className="text-zinc-400 text-lg mb-10 max-w-xl mx-auto">
              Suscríbete a nuestra newsletter VIP y recibe ofertas exclusivas, consejos para revendedores y tu cupón de descuento inmediato.
            </p>
            
            <form className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto" onSubmit={(e) => e.preventDefault()}>
              <input
                type="email"
                placeholder="Tu mejor email..."
                className="flex-grow bg-black/80 border border-white/20 rounded-xl px-6 py-4 text-white focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all text-lg"
                required
              />
              <Button type="submit" size="lg" className="h-[60px] px-8 text-lg font-bold">
                ENVIAR CUPÓN
              </Button>
            </form>
            <p className="text-xs text-zinc-500 mt-4">No enviamos spam. Prometido.</p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
