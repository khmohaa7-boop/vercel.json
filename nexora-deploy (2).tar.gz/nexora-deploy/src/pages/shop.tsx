import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Filter, Package } from "lucide-react";
import { Link } from "wouter";
import { useSuppliers, useBundle } from "@/hooks/use-store";
import { ProductCard } from "@/components/ui/product-card";
import { Category } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { cn, formatPrice } from "@/lib/utils";

const categories: { id: Category | 'todos'; label: string }[] = [
  { id: 'todos', label: 'Todos los accesos' },
  { id: 'auriculares', label: 'AirPods' },
  { id: 'perfumes', label: 'Perfumes' },
  { id: 'ropa', label: 'Ropa' },
];

export default function Shop() {
  const searchParams = new URLSearchParams(window.location.search);
  const catParam = searchParams.get('c') as Category | 'todos' | null;

  const [activeCategory, setActiveCategory] = useState<Category | 'todos'>(catParam || 'todos');
  const suppliers = useSuppliers(activeCategory);
  const bundle = useBundle();
  const showBundle = activeCategory === 'todos';

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-background pt-8 pb-24">
      {/* Header */}
      <div className="bg-zinc-950 border-b border-white/5 py-12 mb-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-4">
            Nuestros <span className="text-primary">Accesos</span>
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Compra el acceso a cualquiera de nuestros proveedores verificados y recibe el enlace directo de forma inmediata.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-8 items-start">

          {/* Filters Sidebar */}
          <aside className="w-full md:w-64 shrink-0 sticky top-24">
            <div className="flex items-center gap-2 mb-6 text-white font-display font-bold text-lg border-b border-white/10 pb-4">
              <Filter className="w-5 h-5 text-primary" />
              Categorías
            </div>
            <div className="flex flex-row md:flex-col gap-2 overflow-x-auto pb-4 md:pb-0">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={cn(
                    "whitespace-nowrap px-4 py-3 rounded-sm text-left transition-all duration-300 font-medium text-sm md:text-base border border-transparent",
                    activeCategory === cat.id
                      ? "bg-primary/10 text-primary border-primary/30 font-bold"
                      : "text-zinc-400 hover:bg-white/5 hover:text-white"
                  )}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </aside>

          {/* Supplier Grid */}
          <div className="flex-grow w-full">
            <div className="flex justify-between items-center mb-6">
              <p className="text-sm text-muted-foreground">
                Mostrando <span className="text-white font-bold">{suppliers.length + (showBundle ? 1 : 0)}</span> opciones
              </p>
            </div>

            <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              <AnimatePresence mode="popLayout">
                {suppliers.map((supplier, i) => (
                  <motion.div
                    key={supplier.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ duration: 0.3 }}
                  >
                    <ProductCard supplier={supplier} index={i} />
                  </motion.div>
                ))}
              </AnimatePresence>
            </motion.div>

            {/* Pack Completo */}
            {showBundle && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="mt-10 relative overflow-hidden rounded-2xl border border-primary/30 bg-black/60"
              >
                <div className="absolute inset-0">
                  <img src={bundle.imageUrl} alt={bundle.name} className="w-full h-full object-cover opacity-20" />
                  <div className="absolute inset-0 bg-gradient-to-r from-black via-black/90 to-transparent" />
                </div>
                <div className="relative z-10 p-8 md:p-12 flex flex-col md:flex-row items-start md:items-center gap-8 justify-between">
                  <div>
                    <div className="inline-block bg-primary text-black text-xs font-bold px-3 py-1 rounded-sm mb-4 uppercase tracking-wider">
                      Mejor Valor — Ahorra {Math.round((1 - bundle.price / bundle.originalPrice) * 100)}%
                    </div>
                    <h3 className="text-2xl md:text-3xl font-display font-bold text-white mb-3 flex items-center gap-3">
                      <Package className="w-7 h-7 text-primary" />
                      {bundle.name}
                    </h3>
                    <p className="text-zinc-300 max-w-xl mb-4">{bundle.description}</p>
                    <ul className="space-y-1 mb-6">
                      {bundle.suppliers.map(s => (
                        <li key={s.id} className="text-sm text-zinc-400 flex items-center gap-2">
                          <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                          {s.name}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="shrink-0 text-center md:text-right">
                    <div className="text-3xl font-bold text-white mb-1">{formatPrice(bundle.price)}</div>
                    <div className="text-sm text-zinc-500 line-through mb-6">{formatPrice(bundle.originalPrice)}</div>
                    <Button asChild size="lg" className="w-full md:w-auto shadow-[0_0_20px_rgba(217,160,32,0.3)]">
                      <Link href="/producto/pack-completo">Ver Pack Completo</Link>
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}

            {suppliers.length === 0 && (
              <div className="text-center py-24">
                <p className="text-xl text-muted-foreground">No se encontraron accesos en esta categoría.</p>
                <Button variant="outline" className="mt-6" onClick={() => setActiveCategory('todos')}>
                  Ver todo el catálogo
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
