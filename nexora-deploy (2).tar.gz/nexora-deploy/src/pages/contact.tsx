import { useState } from "react";
import { motion } from "framer-motion";
import { Send, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Contact() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setSent(true);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center py-24 px-4">
      <div className="w-full max-w-xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          {/* Header */}
          <div className="text-center mb-10">
            <span className="text-primary font-bold tracking-[0.2em] uppercase text-xs mb-4 block">
              Estamos aquí para ayudarte
            </span>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-4">
              Envíanos un mensaje
            </h1>
            <p className="text-zinc-400 text-base">
              Te respondemos en menos de 24 horas.
            </p>
          </div>

          {/* Card */}
          <div className="bg-zinc-900/60 border border-white/10 rounded-2xl p-8 md:p-10 shadow-[0_0_60px_rgba(0,0,0,0.4)]">
            {sent ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4 }}
                className="flex flex-col items-center justify-center py-10 text-center"
              >
                <div className="w-16 h-16 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center mb-6">
                  <CheckCircle className="w-8 h-8 text-primary" />
                </div>
                <h2 className="text-2xl font-display font-bold text-white mb-3">
                  ¡Mensaje recibido!
                </h2>
                <p className="text-zinc-400 max-w-sm">
                  Gracias por contactarnos. Te responderemos en menos de 24 horas.
                </p>
                <button
                  onClick={() => setSent(false)}
                  className="mt-8 text-sm text-primary hover:underline"
                >
                  Enviar otro mensaje
                </button>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-1.5">
                  <label htmlFor="name" className="block text-sm font-medium text-zinc-300">
                    Tu nombre
                  </label>
                  <input
                    id="name"
                    type="text"
                    placeholder="Juan García"
                    required
                    className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-zinc-600 focus:outline-none focus:border-primary/60 transition-colors"
                  />
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="email" className="block text-sm font-medium text-zinc-300">
                    Tu email
                  </label>
                  <input
                    id="email"
                    type="email"
                    placeholder="juan@ejemplo.com"
                    required
                    className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-zinc-600 focus:outline-none focus:border-primary/60 transition-colors"
                  />
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="message" className="block text-sm font-medium text-zinc-300">
                    Mensaje
                  </label>
                  <textarea
                    id="message"
                    rows={5}
                    placeholder="Escribe tu mensaje aquí..."
                    required
                    className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-zinc-600 focus:outline-none focus:border-primary/60 transition-colors resize-none"
                  />
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full h-14 text-base gap-2 shadow-[0_0_20px_rgba(217,160,32,0.15)] hover:shadow-[0_0_30px_rgba(217,160,32,0.3)] transition-shadow mt-2"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                      </svg>
                      Enviando...
                    </span>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      Enviar mensaje
                    </>
                  )}
                </Button>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
