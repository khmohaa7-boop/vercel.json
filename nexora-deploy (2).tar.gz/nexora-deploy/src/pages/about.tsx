import { motion } from "framer-motion";
import { Award, Globe, Gem } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Hero */}
      <section className="relative h-[60vh] flex items-center justify-center">
        <div className="absolute inset-0 z-0">
          {/* generated image */}
          <img 
            src={`${import.meta.env.BASE_URL}images/about-bg.png`} 
            alt="Nuestra historia" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-black/70 to-black/30" />
        </div>
        
        <div className="relative z-10 text-center px-4 max-w-3xl">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-5xl md:text-7xl font-display font-bold text-white mb-6"
          >
            NUESTRA <span className="text-primary">HISTORIA</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-xl text-zinc-300 font-light"
          >
            Redefiniendo el lujo accesible a través de una selección meticulosa.
          </motion.p>
        </div>
      </section>

      <section className="container mx-auto px-4 py-20">
        <div className="max-w-3xl mx-auto text-center mb-24">
          <h2 className="text-3xl font-display font-bold text-white mb-8">La Visión NEXORA</h2>
          <div className="space-y-6 text-lg text-zinc-400 leading-relaxed font-light text-left md:text-justify">
            <p>
              Nacimos con una idea clara: el lujo y la calidad premium no deberían estar limitados por fronteras físicas ni precios inaccesibles. 
              En NEXORA STORE, nos dedicamos a recorrer el mundo (digital y físico) para encontrar aquellos productos que realmente marcan la diferencia.
            </p>
            <p>
              No somos una tienda más. Somos curadores. Cada fragancia, cada auricular y cada prenda que ves en nuestro catálogo ha pasado por un 
              riguroso proceso de selección. Si no cumple con nuestros estándares de excelencia, no entra en NEXORA.
            </p>
            <p>
              Nuestro modelo de negocio directo y colaborativo nos permite conectar a los creadores de los mejores productos directamente contigo, 
              eliminando intermediarios innecesarios y garantizando que siempre obtengas el mejor valor posible.
            </p>
          </div>
        </div>

        {/* Values Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 max-w-5xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center p-8 bg-card border border-white/5 rounded-2xl hover:border-primary/30 transition-colors"
          >
            <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-6 text-primary">
              <Gem className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-display font-bold text-white mb-4">Calidad Incondicional</h3>
            <p className="text-zinc-400 text-sm">Materiales premium y acabados perfectos. La excelencia es nuestra única métrica.</p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-center p-8 bg-card border border-white/5 rounded-2xl hover:border-primary/30 transition-colors"
          >
            <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-6 text-primary">
              <Globe className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-display font-bold text-white mb-4">Alcance Global</h3>
            <p className="text-zinc-400 text-sm">Buscamos talento y productos excepcionales en todos los rincones del planeta.</p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-center p-8 bg-card border border-white/5 rounded-2xl hover:border-primary/30 transition-colors"
          >
            <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-6 text-primary">
              <Award className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-display font-bold text-white mb-4">Servicio Premium</h3>
            <p className="text-zinc-400 text-sm">Tu satisfacción es primordial. Soporte dedicado y garantías reales en cada compra.</p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
