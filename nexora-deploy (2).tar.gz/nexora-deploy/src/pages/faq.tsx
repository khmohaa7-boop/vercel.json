import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const faqs = [
  {
    question: "¿Cuánto tarda en llegar mi pedido?",
    answer: "Para productos en stock, el envío estándar tarda entre 2 y 4 días hábiles. Para artículos de edición limitada o bajo demanda (dropshipping premium), el tiempo puede variar entre 7 y 14 días. Siempre te proporcionaremos un número de seguimiento."
  },
  {
    question: "¿Cómo funciona el proceso de compra?",
    answer: "NEXORA STORE funciona como un curador premium. Al hacer clic en 'Comprar Ahora' en algunos artículos, serás redirigido a la pasarela de pago segura de nuestro proveedor asociado para finalizar la compra con todas las garantías. En otros productos, el pago se procesa directamente en nuestra plataforma."
  },
  {
    question: "¿Aceptan devoluciones?",
    answer: "Sí, la satisfacción total es nuestro compromiso. Tienes 30 días desde la recepción del producto para solicitar una devolución, siempre que el artículo esté en perfectas condiciones y en su embalaje original."
  },
  {
    question: "¿Los perfumes son originales?",
    answer: "Absolutamente. Todos nuestros perfumes y productos de belleza provienen directamente de los fabricantes o distribuidores autorizados. Garantizamos la autenticidad al 100%."
  },
  {
    question: "¿Ofrecen garantía en los productos tecnológicos?",
    answer: "Sí, todos los auriculares y gadgets tecnológicos incluyen una garantía del fabricante de 2 años contra defectos de fábrica."
  },
  {
    question: "¿Hacen envíos internacionales?",
    answer: "Actualmente enviamos a España, resto de Europa y Estados Unidos. Estamos trabajando para expandir nuestras fronteras de envío muy pronto."
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="min-h-screen bg-background pt-12 pb-24">
      <div className="container mx-auto px-4 max-w-3xl">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-4">Preguntas Frecuentes</h1>
          <p className="text-muted-foreground text-lg">
            Todo lo que necesitas saber sobre comprar en NEXORA STORE.
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div 
              key={index}
              className="bg-card border border-white/5 rounded-lg overflow-hidden transition-colors hover:border-white/10"
            >
              <button
                className="w-full px-6 py-5 flex items-center justify-between focus:outline-none"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <h3 className="text-lg font-medium text-white text-left pr-4">{faq.question}</h3>
                <ChevronDown 
                  className={cn(
                    "w-5 h-5 text-primary shrink-0 transition-transform duration-300",
                    openIndex === index ? "rotate-180" : ""
                  )} 
                />
              </button>
              
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="px-6 pb-6 pt-0 text-zinc-400 leading-relaxed border-t border-white/5 mt-2 pt-4">
                      {faq.answer}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
