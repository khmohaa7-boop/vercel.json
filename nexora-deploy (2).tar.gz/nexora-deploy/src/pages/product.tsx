import { useEffect } from "react";
import { useParams, Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowLeft, Zap, ShieldCheck, Infinity, ExternalLink, Package } from "lucide-react";
import { useSupplier, useBundle } from "@/hooks/use-store";
import { formatPrice } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { StarRating } from "@/components/ui/star-rating";
import { ProductCard } from "@/components/ui/product-card";
import { suppliers } from "@/lib/data";

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const supplier = useSupplier(id || "");
  const bundle = useBundle();
  const isBundle = id === 'pack-completo';

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  // Related suppliers (others not this one)
  const related = suppliers.filter(s => s.id !== id).slice(0, 3);

  if (!supplier && !isBundle) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center text-center px-4">
        <h2 className="text-3xl font-display font-bold text-white mb-4">Acceso no encontrado</h2>
        <p className="text-muted-foreground mb-8">El acceso que buscas no existe o ha sido retirado.</p>
        <Button asChild>
          <Link href="/tienda">Volver a la tienda</Link>
        </Button>
      </div>
    );
  }

  if (isBundle) {
    return (
      <div className="min-h-screen bg-background pb-24">
        <div className="bg-zinc-950 border-b border-white/5 py-4">
          <div className="container mx-auto px-4">
            <Link href="/tienda" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" /> Volver al catálogo
            </Link>
          </div>
        </div>

        <div className="container mx-auto px-4 py-12">
          <div className="flex flex-col lg:flex-row gap-12 lg:gap-20">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="w-full lg:w-1/2"
            >
              <div className="aspect-square bg-card rounded-2xl overflow-hidden border border-white/5 relative group">
                <div className="absolute top-6 left-6 z-10 bg-primary text-black text-xs font-bold tracking-widest uppercase px-4 py-1.5 rounded-sm shadow-lg">
                  Mejor Valor
                </div>
                <img src={bundle.imageUrl} alt={bundle.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-80" />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="w-full lg:w-1/2 flex flex-col justify-center"
            >
              <div className="mb-2 text-primary font-bold tracking-widest uppercase text-xs flex items-center gap-2">
                <Package className="w-4 h-4" /> Pack Completo
              </div>
              <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-6">
                {bundle.name}
              </h1>

              <div className="flex items-end gap-4 mb-6">
                <span className="text-4xl font-bold text-white">{formatPrice(bundle.price)}</span>
                <span className="text-xl text-zinc-500 line-through mb-1">{formatPrice(bundle.originalPrice)}</span>
                <span className="text-sm font-bold bg-primary/20 text-primary px-2 py-1 rounded-sm">
                  Ahorra {Math.round((1 - bundle.price / bundle.originalPrice) * 100)}%
                </span>
              </div>

              <p className="text-lg text-zinc-400 mb-8 leading-relaxed">{bundle.description}</p>

              <div className="bg-zinc-900/60 border border-white/10 rounded-xl p-6 mb-8">
                <p className="text-sm text-primary font-bold uppercase tracking-wider mb-4">Incluye acceso a:</p>
                <ul className="space-y-3">
                  {bundle.suppliers.map(s => (
                    <li key={s.id} className="flex items-center gap-3 text-zinc-200">
                      <div className="w-2 h-2 rounded-full bg-primary shrink-0" />
                      <span className="font-medium">{s.name}</span>
                      <span className="text-xs text-muted-foreground ml-auto">Enlace directo</span>
                    </li>
                  ))}
                </ul>
              </div>

              <Button
                size="lg"
                className="w-full h-16 text-lg mb-8 shadow-[0_0_20px_rgba(217,160,32,0.2)] hover:shadow-[0_0_30px_rgba(217,160,32,0.4)]"
                onClick={() => window.open('#comprar-pack', '_blank')}
              >
                <ExternalLink className="w-5 h-5 mr-2" />
                Comprar Pack — {formatPrice(bundle.price)}
              </Button>

              <div className="grid grid-cols-3 gap-4 border-t border-white/10 pt-8">
                <div className="flex flex-col items-center text-center">
                  <Zap className="w-6 h-6 text-primary mb-2" />
                  <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Acceso Inmediato</span>
                </div>
                <div className="flex flex-col items-center text-center">
                  <ShieldCheck className="w-6 h-6 text-primary mb-2" />
                  <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Proveedor Verificado</span>
                </div>
                <div className="flex flex-col items-center text-center">
                  <Infinity className="w-6 h-6 text-primary mb-2" />
                  <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Acceso de por Vida</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="bg-zinc-950 border-b border-white/5 py-4">
        <div className="container mx-auto px-4">
          <Link href="/tienda" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" /> Volver al catálogo
          </Link>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-20">

          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="w-full lg:w-1/2"
          >
            <div className="aspect-square bg-card rounded-2xl overflow-hidden border border-white/5 relative group">
              {supplier!.badge && (
                <div className="absolute top-6 left-6 z-10 bg-primary text-black text-xs font-bold tracking-widest uppercase px-4 py-1.5 rounded-sm shadow-lg">
                  {supplier!.badge}
                </div>
              )}
              <img
                src={supplier!.imageUrl}
                alt={supplier!.name}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="w-full lg:w-1/2 flex flex-col justify-center"
          >
            <div className="mb-2 text-primary font-bold tracking-widest uppercase text-xs">
              Acceso a Proveedor — {supplier!.category}
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-4">
              {supplier!.name}
            </h1>

            <div className="flex items-center gap-4 mb-6">
              <StarRating rating={supplier!.rating} count={supplier!.reviewCount} />
              <span className="text-sm text-emerald-400 font-medium bg-emerald-400/10 px-2 py-0.5 rounded-sm">
                Disponible
              </span>
            </div>

            <div className="flex items-end gap-4 mb-8">
              <span className="text-4xl font-bold text-white">{formatPrice(supplier!.price)}</span>
              {supplier!.originalPrice && (
                <span className="text-xl text-zinc-500 line-through mb-1">{formatPrice(supplier!.originalPrice)}</span>
              )}
            </div>

            <p className="text-lg text-zinc-400 mb-8 leading-relaxed">
              {supplier!.description}
            </p>

            <div className="bg-zinc-900/60 border border-white/10 rounded-xl p-6 mb-8">
              <p className="text-sm text-primary font-bold uppercase tracking-wider mb-4">¿Qué recibes?</p>
              <ul className="space-y-3">
                {supplier!.includes.map((item, idx) => (
                  <li key={idx} className="flex items-center text-zinc-300">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary mr-3 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <Button
              size="lg"
              className="w-full h-16 text-lg mb-8 shadow-[0_0_20px_rgba(217,160,32,0.2)] hover:shadow-[0_0_30px_rgba(217,160,32,0.4)]"
              onClick={() => window.open(supplier!.supplierUrl, '_blank')}
            >
              <ExternalLink className="w-5 h-5 mr-2" />
              Comprar Acceso Ahora
            </Button>

            <div className="grid grid-cols-3 gap-4 border-t border-white/10 pt-8">
              <div className="flex flex-col items-center text-center">
                <Zap className="w-6 h-6 text-primary mb-2" />
                <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Acceso Inmediato</span>
              </div>
              <div className="flex flex-col items-center text-center">
                <ShieldCheck className="w-6 h-6 text-primary mb-2" />
                <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Proveedor Verificado</span>
              </div>
              <div className="flex flex-col items-center text-center">
                <Infinity className="w-6 h-6 text-primary mb-2" />
                <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Acceso de por Vida</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Other suppliers */}
      {related.length > 0 && (
        <div className="container mx-auto px-4 pt-24 mt-12 border-t border-white/5">
          <h2 className="text-3xl font-display font-bold text-white mb-8 text-center">Otros Accesos Disponibles</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {related.map(s => (
              <ProductCard key={s.id} supplier={s} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
