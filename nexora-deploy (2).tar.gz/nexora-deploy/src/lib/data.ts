export type Category = 'auriculares' | 'perfumes' | 'ropa';

export interface Supplier {
  id: string;
  name: string;
  tagline: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: Category;
  imageUrl: string;
  supplierUrl: string;
  badge?: 'Más Popular' | 'Oferta' | 'Nuevo';
  includes: string[];
  rating: number;
  reviewCount: number;
}

export interface Bundle {
  id: string;
  name: string;
  description: string;
  suppliers: Supplier[];
  price: number;
  originalPrice: number;
  imageUrl: string;
}

export const suppliers: Supplier[] = [
  {
    id: 'airpods',
    name: 'Proveedor de AirPods',
    tagline: 'Acceso directo al mejor proveedor de auriculares inalámbricos',
    description: 'Al adquirir este acceso, recibirás el enlace directo a nuestro proveedor verificado de AirPods y auriculares inalámbricos premium. Podrás comprar a precios de mayorista, con stock garantizado y envío internacional.',
    price: 9.99,
    originalPrice: 19.99,
    category: 'auriculares',
    imageUrl: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&q=80&w=800',
    supplierUrl: '#acceso-airpods',
    badge: 'Más Popular',
    includes: [
      'Enlace directo al proveedor verificado',
      'Catálogo completo de AirPods y auriculares',
      'Precios de mayorista exclusivos',
      'Soporte para tu primera compra',
      'Acceso de por vida al enlace',
    ],
    rating: 4.9,
    reviewCount: 312,
  },
  {
    id: 'perfumes',
    name: 'Proveedor de Perfumes',
    tagline: 'Acceso directo al mejor proveedor de perfumes de lujo',
    description: 'Al adquirir este acceso, recibirás el enlace directo a nuestro proveedor verificado de perfumes de lujo y fragancias exclusivas. Accede a cientos de referencias internacionales a precios que no encontrarás en ningún otro sitio.',
    price: 9.99,
    originalPrice: 19.99,
    category: 'perfumes',
    imageUrl: 'https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&q=80&w=800',
    supplierUrl: '#acceso-perfumes',
    badge: 'Nuevo',
    includes: [
      'Enlace directo al proveedor verificado',
      'Catálogo de perfumes de lujo internacionales',
      'Precios por debajo del mercado',
      'Asesoría para tu primera compra',
      'Acceso de por vida al enlace',
    ],
    rating: 4.8,
    reviewCount: 186,
  },
  {
    id: 'ropa',
    name: 'Proveedor de Ropa',
    tagline: 'Acceso directo al mejor proveedor de ropa streetwear premium',
    description: 'Al adquirir este acceso, recibirás el enlace directo a nuestro proveedor verificado de ropa streetwear y moda urbana premium. Miles de referencias actualizadas cada temporada a precios incomparables.',
    price: 9.99,
    originalPrice: 19.99,
    category: 'ropa',
    imageUrl: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&q=80&w=800',
    supplierUrl: '#acceso-ropa',
    includes: [
      'Enlace directo al proveedor verificado',
      'Catálogo completo de ropa streetwear',
      'Nuevas colecciones cada temporada',
      'Guía de tallas y pedidos',
      'Acceso de por vida al enlace',
    ],
    rating: 4.7,
    reviewCount: 148,
  },
];

export const completeBundle: Bundle = {
  id: 'pack-completo',
  name: 'Pack Completo — Los 3 Proveedores',
  description: 'Accede a los 3 proveedores verificados de NEXORA STORE en un único pago con descuento especial. Recibirás los 3 enlaces directos: AirPods, Perfumes y Ropa.',
  suppliers,
  price: 19.99,
  originalPrice: 29.97,
  imageUrl: 'https://images.unsplash.com/photo-1616422285623-14bf73e85747?auto=format&fit=crop&q=80&w=800',
};
