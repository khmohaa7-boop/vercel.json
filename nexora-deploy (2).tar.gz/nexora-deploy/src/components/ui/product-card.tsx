import { Link } from "wouter";
import { motion } from "framer-motion";
import { ExternalLink } from "lucide-react";
import { Supplier } from "@/lib/data";
import { formatPrice } from "@/lib/utils";
import { Button } from "./button";
import { StarRating } from "./star-rating";

interface SupplierCardProps {
  supplier: Supplier;
  index?: number;
}

export function ProductCard({ supplier, index = 0 }: SupplierCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group flex flex-col bg-card rounded-lg overflow-hidden border border-white/5 hover:border-primary/30 transition-all duration-500 hover:shadow-[0_8px_30px_rgba(217,160,32,0.08)]"
    >
      <Link href={`/producto/${supplier.id}`} className="relative aspect-square overflow-hidden block">
        {supplier.badge && (
          <div className="absolute top-3 left-3 z-10 bg-primary text-primary-foreground text-[10px] font-bold tracking-widest uppercase px-3 py-1 rounded-sm shadow-lg">
            {supplier.badge}
          </div>
        )}
        <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors duration-500 z-0" />
        <img
          src={supplier.imageUrl}
          alt={supplier.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
      </Link>

      <div className="p-5 flex flex-col flex-grow">
        <Link href={`/producto/${supplier.id}`}>
          <h3 className="font-display text-lg font-bold hover:text-primary transition-colors mb-1">
            {supplier.name}
          </h3>
        </Link>
        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{supplier.tagline}</p>

        <StarRating rating={supplier.rating} count={supplier.reviewCount} className="mb-4" />

        <div className="mt-auto pt-4 flex items-center justify-between border-t border-white/5">
          <div className="flex flex-col">
            <span className="text-xl font-bold text-foreground">{formatPrice(supplier.price)}</span>
            {supplier.originalPrice && (
              <span className="text-sm text-muted-foreground line-through">
                {formatPrice(supplier.originalPrice)}
              </span>
            )}
          </div>

          <Button
            size="sm"
            className="gap-2"
            onClick={(e) => {
              e.preventDefault();
              window.open(supplier.supplierUrl, '_blank');
            }}
          >
            <ExternalLink className="w-3.5 h-3.5" />
            Acceder
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
