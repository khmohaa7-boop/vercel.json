import { useState, useEffect } from "react";

export function CountdownTimer({ hours = 2, minutes = 15, seconds = 0 }) {
  const [timeLeft, setTimeLeft] = useState({
    hours,
    minutes,
    seconds
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.hours === 0 && prev.minutes === 0 && prev.seconds === 0) {
          clearInterval(timer);
          return prev;
        }

        let newH = prev.hours;
        let newM = prev.minutes;
        let newS = prev.seconds - 1;

        if (newS < 0) {
          newM -= 1;
          newS = 59;
        }
        if (newM < 0) {
          newH -= 1;
          newM = 59;
        }

        return { hours: newH, minutes: newM, seconds: newS };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const format = (num: number) => num.toString().padStart(2, '0');

  return (
    <div className="flex items-center gap-2 text-2xl md:text-4xl font-display font-bold text-gradient-gold">
      <div className="flex flex-col items-center">
        <span>{format(timeLeft.hours)}</span>
        <span className="text-[10px] font-sans tracking-widest text-muted-foreground uppercase uppercase">Horas</span>
      </div>
      <span className="pb-4">:</span>
      <div className="flex flex-col items-center">
        <span>{format(timeLeft.minutes)}</span>
        <span className="text-[10px] font-sans tracking-widest text-muted-foreground uppercase">Min</span>
      </div>
      <span className="pb-4">:</span>
      <div className="flex flex-col items-center">
        <span>{format(timeLeft.seconds)}</span>
        <span className="text-[10px] font-sans tracking-widest text-muted-foreground uppercase">Seg</span>
      </div>
    </div>
  );
}
